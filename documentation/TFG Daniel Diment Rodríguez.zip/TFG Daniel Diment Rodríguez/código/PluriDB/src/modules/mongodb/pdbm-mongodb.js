module.exports = {
    api: {
        mongodb: function (execute) {

        }
    },
    parser: {
        mongodb: function (db) {

        }
    }
};
