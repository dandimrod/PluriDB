const PluriDB = require('./PluriDB');

const db = PluriDB();

console.log(db);
