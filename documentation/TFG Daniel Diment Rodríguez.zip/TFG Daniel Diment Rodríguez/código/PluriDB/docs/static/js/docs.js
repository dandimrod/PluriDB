window.$docsify = {
    el: '#app',
    loadSidebar: true,
    subMaxLevel: 2,
    search: 'auto'
}