function Menu (menuElement, options) {

};

options = {
    sections: {},
    layouts: {
        
    }
};