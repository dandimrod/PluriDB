# oikometer
Open service to keep track of your domestic economy
