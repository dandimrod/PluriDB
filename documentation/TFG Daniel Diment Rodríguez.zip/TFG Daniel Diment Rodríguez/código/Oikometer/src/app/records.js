const fs = require('fs/promises');

const categories = [
    {
        name:()=>{
            return 'Salary from ABC-inc';
        },
        chances:[1],
        value: ()=>{
            return 3500
        },
        date: ()=>{
            return 2;
        }
    },
    {
        name:()=>{
            return 'Transference Restaurant Caposhes'
        },
        chances:[3,5,4,4,2],
        value: ()=>{
            return randomInt(-120,-30,2);
        },
        date: ()=>{
            return randomInt(1,31,0);
        }
    },
    {
        name:()=>{
            return 'Transference Supermarket Glaschaeder'
        },
        chances:[3,5,4,4,2,7],
        value: ()=>{
            return randomInt(-200,-20,2);
        },
        date: ()=>{
            return randomInt(1,31,0);
        }
    },
    {
        name:()=>{
            return 'Transference Supermarket Glaschaeder'
        },
        chances:[3,5,4,4,2,7],
        value: ()=>{
            return randomInt(-200,-20,2);
        },
        date: ()=>{
            return randomInt(1,31,0);
        }
    },
    {
        name:()=>{
            return 'Transference Online Shopping Gagustha'
        },
        chances:[3,5,4,4,2,7,0,1],
        value: ()=>{
            return randomInt(-200,-20,2);
        },
        date: ()=>{
            return randomInt(1,31,0);
        }
    },
    {
        name:()=>{
            return 'Transference from Steve Joe'
        },
        chances:[3,5,4,4,2,7,0,1],
        value: ()=>{
            return randomInt(-20,20,2);
        },
        date: ()=>{
            return randomInt(1,31,0);
        }
    },
    {
        name:()=>{
            return 'Transference Electric Sflinder'
        },
        chances:[1],
        value: ()=>{
            return randomInt(-250, -200, 2);
        },
        date: ()=>{
            return 5;
        }
    },
    {
        name:()=>{
            return 'Transference Waters Galgoeis'
        },
        chances:[1,0,0],
        value: ()=>{
            return randomInt(-100, -80, 2);
        },
        date: ()=>{
            return 6;
        }
    },
    {
        name:()=>{
            return 'Transference Internet FeFa Telecomunications'
        },
        chances:[1],
        value: ()=>{
            return -65;
        },
        date: ()=>{
            return 8;
        }
    },
]

const months = 15;
let lines = '';

for (let index = 0; index < months; index++) {
    const thisMonth = new Date();
    thisMonth.setMonth(thisMonth.getMonth()-index);
    for (const category of categories) {
        const selectedChance = category.chances[randomInt(0,category.chances.length-1)];
        for (let index = 0; index < selectedChance; index++) {
            const name = category.name();
            const value = category.value();
            const day =category.date();
            const date = new Date(randomInt(
                new Date(thisMonth.getFullYear(), thisMonth.getMonth(), day).getTime(),
                new Date(thisMonth.getFullYear(), thisMonth.getMonth(), day+1).getTime(),
            ));   
            const line = `${name},${value},${date.toISOString()}\n`;
            lines += line;    
        }
    }
}

// for (let index = 0; index < 1000; index++) {
//     const name = 'This is the record '+index;
//     const value = randomInt(-1000,1000,2);
//     const date = new Date(randomInt(new Date(2020,1,1),new Date().getTime(),0));
//     const line = `${name},${value},${date.toISOString()}\n`;
//     lines += line;
// }

function randomInt(min,max,dec=0){
    min = Math.ceil(min)*(Math.pow(10,dec));
    max = Math.floor(max)*(Math.pow(10,dec));
    return (Math.floor(Math.random() * (max - min + 1)) + min)/Math.pow(10,dec);
}

fs.writeFile('./records.csv',lines);