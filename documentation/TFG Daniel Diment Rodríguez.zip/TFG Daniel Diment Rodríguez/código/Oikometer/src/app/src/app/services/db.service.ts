import { Injectable } from '@angular/core';
// eslint-disable-next-line @typescript-eslint/naming-convention
declare let PluriDB: any;
export interface Balance {
  total: number;
  gains: number;
  losses: number;
}
export interface Configuration {
  currency: string;
  language: string;
}
export interface Record {
  id: string;
  concept: string;
  value: number;
  date: Date;
  notes?: string;
  category?: string;
}
export interface Category {
  id: string;
  name: string;
  periodic: boolean;
  color: string;
  category?: string;
}
export interface Rule {
  id: string;
  name: string;
  type: string;
  category: string;
  checker: string;
}
let db: any;
@Injectable({
  providedIn: 'root'
})
export class DbService {
  public loggedIn = false;

  public configuration: Configuration = {
    currency: 'USD',
    language: 'en-US'
  };

  public query(){
    return db.m.default.promise;
  }

  public scopedFunction(){
    return db.m.default.scopedFunction;
  }
  public async changeConfig(configuration: Configuration){
    const afterOp = await this.query().data.updateData('rule', {
      currency:configuration.currency,
      language:configuration.language
    }, (temp: any, tempId: string)=>tempId==='0');
    if(afterOp.error){
      return afterOp.error;
    }else {
      this.configuration = configuration;
      return '';
    }
  }
  public async changePassword(password: string){
    const afterOp = await db.promise.updateDb({encrypt:false});
    if(afterOp.error){
      return afterOp.error;
    }else {
      return '';
    }
  }
  public async login(user: string, pass: string){
    db = new PluriDB('oikometer-' + user, {
      db:{
          encrypt: false,
      }
    });
    await db.init();
    // Configuration db initialization
    await db.m.default.promise.tables.createTable('configuration', {columns:{
      currency:{
        type: 'string',
      },
      language: {
        type: 'string',
      }
    }});
    const tempConfig = await db.m.default.promise.data.getData('configuration');
    if(tempConfig && tempConfig.result['0']){
      this.configuration = tempConfig.result['0'];
    }else{
      await db.m.default.promise.data.createData('configuration', this.configuration);
    }
    // Categories db initialization
    await db.m.default.promise.tables.createTable('category', {columns:{
      name:{
        type: 'string',
      },
      periodic: {
        type: 'boolean',
      },
      color: {
        type: 'string'
      },
      category: {
        type: 'reference',
        to: 'category'
      }
    }});
    const checkCategories = await db.m.default.promise.data.getData('category');
    if(!checkCategories.result['0']){
      console.log('no checkCategories');
    }
    // Rules db initialization
    await db.m.default.promise.tables.createTable('rule', {columns:{
      name:{
        type: 'string',
      },
      type: {
        type: 'string',
      },
      checker: {
        type: 'string'
      },
      category: {
        type: 'reference',
        to: 'category'
      }
    }});
    // Records db initialization
    await db.m.default.promise.tables.createTable('record', {columns:{
      concept:{
        type: 'string',
      },
      value: {
        type: 'number',
      },
      date: {
        type: 'number'
      },
      notes: {
        type: 'string'
      },
      category: {
        type: 'reference',
        to: 'category'
      }
    }});

    this.loggedIn = true;
  };
  public async drop(){
    db.drop();
    this.loggedIn=false;
  }
}
