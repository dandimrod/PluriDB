import { Component, OnInit } from '@angular/core';
import { Configuration, DbService } from 'src/app/services/db.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.css']
})
export class ConfigComponent implements OnInit {
  public configuration: Configuration = {
    language:'US-us',
    currency:'USD'
  };
  public password = '';
  constructor(public db: DbService, private snackBar: MatSnackBar) {
  }

  ngOnInit(): void {
    this.configuration = JSON.parse(JSON.stringify(this.db.configuration));
  }
  public async saveConfig(){
    const error = await this.db.changeConfig(this.configuration);
    if(error){
      this.snackBar.open(error,undefined,{
        duration: 5000,
      });
    }else{
      this.snackBar.open('Done', undefined, {
        duration: 5000,
      });
    }
  }
  public async savePassword(){
    const error = await this.db.changePassword(this.password);
    this.password = '';
    if(error){
      this.snackBar.open(error,undefined,{
        duration: 5000,
      });
    }else{
      this.snackBar.open('Done', undefined, {
        duration: 5000,
      });
    }
  }
  public importData(){

  }
  public exportData(){

  }
  public deleteData(){
    if(confirm('Are you sure you want to delete all your data?')){
      this.db.drop();
    }
  }
}
