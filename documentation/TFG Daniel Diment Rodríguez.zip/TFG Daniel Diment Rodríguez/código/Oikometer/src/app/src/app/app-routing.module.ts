import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CategoriesComponent } from './main/categories/categories.component';
import { ConfigComponent } from './main/config/config.component';
import { RecordsComponent } from './main/records/records.component';
import { RulesComponent } from './main/rules/rules.component';
import { ViewerComponent } from './main/viewer/viewer.component';
import { NotFoundComponent } from './not-found/not-found.component';
const routes: Routes = [
  { path:'', component: ViewerComponent },
  { path:'rules', component: RulesComponent },
  { path:'settings', component: ConfigComponent },
  { path:'categories', component: CategoriesComponent },
  { path:'records', component: RecordsComponent },
  { path:'records#:id', component: RecordsComponent },
  { path:'**', component: NotFoundComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
