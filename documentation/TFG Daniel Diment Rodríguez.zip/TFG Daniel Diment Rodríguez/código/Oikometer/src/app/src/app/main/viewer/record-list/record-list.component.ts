import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';
import { RecordService } from 'src/app/services/record.service';
import { DbService, Record } from '../../../services/db.service';
import { UtilsService } from '../../../services/utils.service';

@Component({
  selector: 'app-record-list',
  templateUrl: './record-list.component.html',
  styleUrls: ['./record-list.component.css']
})
export class RecordListComponent implements OnInit {
  constructor(
    public db: DbService,
    public utils: UtilsService,
    public recordService: RecordService,
    public categoryService: CategoryService
  ) { }

  ngOnInit(): void {
  }
  public deleteRecord(id: string){
    if(confirm('Are you sure you want to delete this record?')){
      this.recordService.deleteRecord(id);
    }
  }

  public async updateNotes(id: string, event: any){
    const record = await this.recordService.getRecord(id);
    if(record){
      record.notes=event.target.value;
      await this.recordService.modifyRecord(record);
    }
  }

  public changePage(event: any){
    this.recordService.updateFilter.page(event.pageIndex);
  }

  public findCategory(id: string|undefined) {
    return this.categoryService.categories.find(category=>category.id===id) || {name:'', color:'#FFF'};
  }
}
