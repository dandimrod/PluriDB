import { Component, OnInit } from '@angular/core';
import { RecordService } from 'src/app/services/record.service';
import { Balance, DbService } from '../../../services/db.service';
import { UtilsService } from '../../../services/utils.service';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {
  public thisMonth = new Date().getMonth() + '-' + new Date().getFullYear();

  constructor(public recordService: RecordService, public utils: UtilsService) {
    recordService.monthBalance(new Date().getMonth(), new Date().getFullYear());
  }

  ngOnInit(): void {
  }

}
