import { Component, OnInit } from '@angular/core';
import { Rule } from 'src/app/services/db.service';
import { RulesService } from 'src/app/services/rules.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CategoryService } from 'src/app/services/category.service';

@Component({
  selector: 'app-rules',
  templateUrl: './rules.component.html',
  styleUrls: ['./rules.component.css']
})
export class RulesComponent implements OnInit {
  public editing = false;
  public editId: string | undefined = undefined;
  public editingRule: Rule = {
    name:'',
    type:'regex',
    id:'',
    checker: '',
    category: ''
  };
  constructor(public ruleService: RulesService, public categoryService: CategoryService,private snackBar: MatSnackBar) { }
  public editRule(id?: string){
    this.editId = id;
    if(typeof this.editId === 'string'){
      this.editingRule = JSON.parse(JSON.stringify(this.ruleService.rules.find(rule=>rule.id===this.editId)));
    }else{
      this.editingRule = {
        name:'',
        type:'regex',
        id:'',
        checker: '',
        category: ''
      };
    }
    this.editing = true;
  }
  public deleteRule(id: string) {
    if(confirm('Are you sure you want to delete this record?')){
      this.ruleService.deleteRule(id);
    }
  }
  public cancelEditing() {
    this.editing = false;
  }
  public async save() {
    const error = await this.ruleService.saveRule(this.editingRule);
    if(error){
      this.snackBar.open(error,undefined,{
        duration: 5000,
      });
    }else{
      this.snackBar.open('Done', undefined, {
        duration: 5000,
      });
      this.editing = false;
    }
  }

  public findCategory(id: string) {
    return this.categoryService.categories.find(category=>category.id===id) || {name:'', color:'#000'};
  }
  ngOnInit(): void {
  }

}
