import { Injectable } from '@angular/core';
import { DbService, Rule, Record } from './db.service';

@Injectable({
  providedIn: 'root'
})
export class RulesService {
  public rules: Array<Rule> = [];
  constructor(private db: DbService) {
    this.getRules();
  }
  public async getRules(){
    const rules = await this.db.query().data.getData('rule');
    this.rules = Object.keys(rules.result).map((ruleID)=>{
      const rule = rules.result[ruleID];
      return {id:ruleID, ...rule};
    });
  }
  public async saveRule(rule: Rule): Promise<string>{
    let afterOp;
    if(rule.id!==''){
      const { id } = rule;
      afterOp = await this.db.query().data.updateData('rule', {
        name:rule.name,
        type:rule.type,
        checker:rule.checker,
        category:rule.category
      }, new Function('return ' + `function(...args){
        let {${Object.keys({ id })}} = JSON.parse('${JSON.stringify({ id })}');
        return ((value,tempId)=>tempId === id)(...args);
      }`)());
    }else{
      afterOp = await this.db.query().data.createData('rule', {
        name:rule.name,
        type:rule.type,
        checker:rule.checker,
        category:rule.category
      });
    }
    await this.getRules();
    if(afterOp.error){
      return afterOp.error;
    }else {
      return '';
    }
  }
  public async deleteRule(id: string){
    const afterOp = await this.db.query().data.deleteData(
      'rule', new Function('return ' + `function(...args){
        let {${Object.keys({ id })}} = JSON.parse('${JSON.stringify({ id })}');
        return ((value,tempId)=>tempId === id)(...args);
      }`)()
    );
    await this.getRules();
    if(afterOp.error){
      return afterOp.error;
    }else {
      return '';
    }
  }

  public async checkRules(record: Record){
    if(record.category===''){
      for (const rule of this.rules){
        try {
          const regex = new RegExp(rule.checker);
          if(regex.test(record.concept)){
            record.category=rule.category;
            break;
          }
        } catch (error) {
          continue;
        }
      }
    }
  }
}
