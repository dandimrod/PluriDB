import { Component, ElementRef, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import {
  Chart,
  ArcElement,
  LineElement,
  BarElement,
  PointElement,
  BarController,
  BubbleController,
  DoughnutController,
  LineController,
  PieController,
  PolarAreaController,
  RadarController,
  ScatterController,
  CategoryScale,
  LinearScale,
  LogarithmicScale,
  RadialLinearScale,
  TimeScale,
  TimeSeriesScale,
  Filler,
  Legend,
  Title,
  Tooltip
} from 'chart.js';
import { DbService } from 'src/app/services/db.service';
import { RecordService } from 'src/app/services/record.service';
import { UtilsService } from 'src/app/services/utils.service';

Chart.register(
  ArcElement,
  LineElement,
  BarElement,
  PointElement,
  BarController,
  BubbleController,
  DoughnutController,
  LineController,
  PieController,
  PolarAreaController,
  RadarController,
  ScatterController,
  CategoryScale,
  LinearScale,
  LogarithmicScale,
  RadialLinearScale,
  TimeScale,
  TimeSeriesScale,
  Filler,
  Legend,
  Title,
  Tooltip
);

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit, AfterViewInit {
  @ViewChild('canvas') canvas: any;
  dateFormCtrl = new FormControl(new Date());
  date = this.dateFormCtrl.value;
  showMonths = 3;
  data: any = {
    type: 'scatter',
    data: {
      labels: [],
      datasets: [{
        type: 'line',
        label: 'Total',
        data: [],
        fill: false,
        borderColor: '#1D6796',
        backgroundColor: '#1D6796',
        yAxisID: 'total'
      },
      {
        type: 'bar',
        label: 'Gains',
        data: [],
        borderColor: '#2EC4B6',
        backgroundColor: '#2EC4B6',
        yAxisID: 'monthly'
      },
      {
        type: 'bar',
        label: 'Losses',
        data: [],
        borderColor: '#E33742',
        backgroundColor: '#E33742',
        yAxisID: 'monthly'
      }]
    },
    options: {
      scales: {
        yAxes: [{
          display: true,
          id: 'monthly',
          type: 'linear',
          position: 'left',
          scaleLabel: {
            display: true,
            labelString: 'Monthly',
            beginAtZero: true,
          }
        }, {
          display: true,
          id: 'total',
          type: 'linear',
          position: 'right',
          scaleLabel: {
              display: true,
              labelString: 'Total',
              beginAtZero: true,
          }
        }]
      },
      plugins:{
        tooltip:{
          callbacks:{
            label : (context: any)=>{
              let label = context.label || '';
              if (label) {
                  label += ': ';
              }
              if (context.parsed.y !== null) {
                  label += this.utils.displayCurrency(context.parsed.y);
              }
              return label;
            }
          }
        }
      }
    }
  };
  chart: any;
  constructor(public recordService: RecordService, public utils: UtilsService) {
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    this.chart = new Chart(this.canvas.nativeElement.getContext('2d'), this.data);
    this.updateChart();
    this.recordService.addEventListener('modifyRecord',()=>{
      this.updateChart();
    });
  }
  async updateChart(): Promise<void> {
    const gains = [];
    const total = [];
    const losses = [];
    const labels = [];
    const currentDate = new Date(this.date.getTime());
    this.recordService.updateFilter.date(currentDate.getMonth(), currentDate.getFullYear(), this.showMonths);
    for (let index = 0; index < this.showMonths; index++) {
      if (index !== 0) {
        let month = currentDate.getMonth();
        let year = currentDate.getFullYear();
        month--;
        if (month === -1) {
          month = 11;
          year--;
        }
        currentDate.setFullYear(year);
        currentDate.setMonth(month);
      }
      labels.unshift((currentDate.getMonth() + 1) + '-' + currentDate.getFullYear());
      const balance = await this.recordService.monthBalance(currentDate.getMonth(), currentDate.getFullYear());
      gains.unshift(balance.gains);
      total.unshift(balance.total);
      losses.unshift(-balance.losses);
    }
    this.chart.data.labels = labels;
    this.chart.data.datasets[0].data = total;
    this.chart.data.datasets[1].data = gains;
    this.chart.data.datasets[2].data = losses;
    this.chart.scales.yAxes.options.display = false;
    this.chart.scales.monthly.options.title.text = 'Monthly';
    this.chart.scales.monthly.options.title.display = true;
    this.chart.scales.total.options.title.text = 'Total';
    this.chart.scales.total.options.title.display = true;
    this.chart.update();
  }
  changeMonths(increase: boolean): void {
    if (increase) {
      this.showMonths++;
    } else {
      this.showMonths--;
    }
    if (this.showMonths < 1) {
      this.showMonths = 1;
    }
    if (this.showMonths > 12) {
      this.showMonths = 12;
    }
    this.updateChart();
  }
  shiftDate(increase: boolean): void {
    this.date.setDate(1);
    let month = this.date.getMonth();
    let year = this.date.getFullYear();
    const now = new Date();
    if (increase) {
      month++;
      if (month === 12) {
        month = 0;
        year++;
      }
      if (year > now.getFullYear() || (year === now.getFullYear() && month > now.getMonth())) {
        return;
      }
    } else {
      month--;
      if (month === -1) {
        month = 11;
        year--;
      }
    }
    this.date.setFullYear(year);
    this.date.setMonth(month);
    this.updateChart();
  }
  openDatePicker(dp: any){
    dp.open();
  }
  closeDatePicker(eventData: any, dp?: any){
    this.date = eventData;
    dp.close();
    this.updateChart();
  }
}
