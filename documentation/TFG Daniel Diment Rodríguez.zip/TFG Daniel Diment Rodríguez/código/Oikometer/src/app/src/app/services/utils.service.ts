import { Injectable } from '@angular/core';
import { DbService } from './db.service';

@Injectable({
  providedIn: 'root'
})
export class UtilsService {

  constructor(public db: DbService) {
  }

  public displayCurrency(cuantity: number): string{
    return cuantity.toLocaleString(this.db.configuration.language, { style:'currency', currency: this.db.configuration.currency });
  }

  public displayDate(date: Date): string{
    return date.toLocaleString(this.db.configuration.language, {
      weekday: 'long' , year: 'numeric', month: 'numeric', day:'numeric', hour:'numeric', minute:'numeric', second:'numeric'
    });
  }
}
