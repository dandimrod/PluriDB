import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';
import { Category } from 'src/app/services/db.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  public editing = false;
  public editId: string | undefined = undefined;
  public editingCategory: Category = {
    name:'',
    color:'#000000',
    id:'',
    periodic: false
  };
  constructor(public categoryService: CategoryService, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
  }
  public editCategory(id?: string){
    this.editId = id;
    if(typeof this.editId === 'string'){
      this.editingCategory = JSON.parse(JSON.stringify(this.categoryService.categories.find(category=>category.id===this.editId)));
    }else{
      this.editingCategory = {
        name:'',
        color:'#000000',
        id:'',
        periodic: false
      };
    }
    this.editing = true;
  }
  public deleteCategory(id: string) {
    if(confirm('Are you sure you want to delete this record?')){
      this.categoryService.deleteCategory(id);
    }
  }

  public filterCategories(): Category[] {
    return this.categoryService.categories.filter(category=>!category.category||category.category==='');
  }
  public cancelEditing() {
    this.editing = false;
  }
  public async save() {
    const error = await this.categoryService.saveCategory(this.editingCategory);
    if(error){
      this.snackBar.open(error,undefined,{
        duration: 5000,
      });
    }else{
      this.snackBar.open('Done', undefined, {
        duration: 5000,
      });
      this.editing = false;
    }
  }

  public findCategory(id: string) {
    return this.categoryService.categories.find(category=>category.id===id) || {name:'', color:'#000'};
  }
}
