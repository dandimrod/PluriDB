import { Injectable } from '@angular/core';
import { RulesService } from './rules.service';
import { Balance, DbService, Record } from './db.service';

interface Filters {
  page?: number;
  category?: string[];
  month?: number;
  year?: number;
  numberOfMonths?: number;
  gains?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class RecordService {
  public allRecords = 0;
  public records: Array<Record> = [];
  public balances: {[key: string]: Balance} = {};

  public updateFilter = {
    page: (value: number): void => {
      this.filters.page = value;
      this.events.forEach(event=>event.event==='changePage'?event.callback():'');
      this.getRecords();
    },
    category: (value?: string[]): void => {
      this.filters.category = value;
      this.events.forEach(event=>event.event==='changeCategory'?event.callback():'');
      this.getRecords();
    },
    date: (month: number, year: number, numberOfMonths: number): void => {
      this.filters.month = month;
      this.filters.year = year;
      this.filters.numberOfMonths = numberOfMonths;
      this.events.forEach(event=>event.event==='changeDate'?event.callback():'');
      this.getRecords();
    },
    gains: (value?: boolean)=>{
      this.filters.gains = value;
      this.events.forEach(event=>event.event==='changeGains'?event.callback():'');
      this.getRecords();
    }
  };

  public filters: Filters = {
    page: 0,
    numberOfMonths: 3
  };
  private events: {event: string; callback: () => any}[] = [];
  constructor(private db: DbService, private rulesService: RulesService) {
    this.getRecords();
  }
  public addEventListener(event: string, callback: () => any){
    this.events.push({event, callback});
  }
  public async getRecords() {
    this.records = await this.getRecordsFilter(
      this.filters.page,
      this.filters.category,
      this.filters.month,
      this.filters.year,
      this.filters.numberOfMonths,
      this.filters.gains
    );
    this.allRecords = Object.keys((await this.getRecordsFilter(
      -1,
      this.filters.category,
      this.filters.month,
      this.filters.year,
      this.filters.numberOfMonths,
      this.filters.gains
    ))).length;
  }
  public async updateBalance(){
    const balances = Object.keys(this.balances);
    balances.forEach(balance=>{
      const splittedBalance = balance.split('-');
      const month = Number(splittedBalance[0]);
      const year = Number(splittedBalance[1]);
      if(!isNaN(month) && !isNaN(year)){
        this.monthBalance(month, year);
      }
    });
  }

  public async monthBalance(month: number, year: number): Promise<Balance>{
    let balance = {
      total: 0,
      gains: 0,
      losses: 0
    };
    const queryResult = await this.db.query().data.getData('record', undefined, undefined, [{
      type:'reduce',
      initialValue:balance,
      executable: new Function('return ' + `function(...args){
        let {${Object.keys({ month, year })}} = JSON.parse('${JSON.stringify({ month, year })}');
        return ((currentBalance, record) => {
        const startMonth = new Date(year, month, 1);
        const endMonth = new Date(year, month+1, 1);
        const recordDate = new Date(record.date);
        if(recordDate<endMonth){
          if(recordDate>startMonth){
            if(record.value>0){
              currentBalance.gains+=record.value;
            }else{
              currentBalance.losses+=record.value;
            }
          }
          currentBalance.total+=record.value;
        }
        return currentBalance;
      })(...args);
    }`)()
    }]);
    balance = queryResult.result;
    this.balances[month+'-'+year] = balance;
    return balance;
  }
  public async getRecord(id: string): Promise<Record|null>{
    const queryResult = await this.db.query().data.getData(
      'record',
      new Function('return ' + `function(...args){
        let {${Object.keys({ id })}} = JSON.parse('${JSON.stringify({ id })}');
        return ((value,tempId)=>tempId === id)(...args);
      }`)()
    );
    if(queryResult.result[Object.keys(queryResult.result)[0]]){
      const record = {id, ...queryResult.result[Object.keys(queryResult.result)[0]]};
      record.date = new Date(record.date);
      return record;
    }else {
      return null;
    }
  }

  public async modifyRecord(record: Record, noUpdateAfter?: boolean){
    this.rulesService.checkRules(record);
    let result;
    if(record.id!==''){
      result = this.updateRecord(record.id,record.concept,record.value,record.date,record.notes,record.category);
    }else{
      result = this.addRecord(record.concept,record.value,record.date,record.notes,record.category);
    }
    if(!noUpdateAfter){
      await this.getRecords();
      this.events.forEach(event=>event.event==='modifyRecord'?event.callback():'');
    }
    return result;
  }
  public async addRecords(records: Record[]): Promise<string>{
    await this.db.query().utils.startTransaction();
    const recordsOp = records.map(record=>this.modifyRecord(record, true));
    const errorList = await Promise.all(recordsOp);
    const error = errorList.find(errorTmp=>errorTmp!=='') || '';
    await this.db.query().utils.endTransaction();
    await this.getRecords();
    this.events.forEach(event=>event.event==='modifyRecord'?event.callback():'');
    return error;
  }
  public async deleteRecord(id: string): Promise<string> {
    const afterRecord = await this.db.query().data.deleteData(
      'record',
      new Function('return ' + `function(...args){
        let {${Object.keys({ id })}} = JSON.parse('${JSON.stringify({ id })}');
        return ((value,tempId)=>tempId === id)(...args);
      }`)()
    );
    await this.getRecords();
    this.events.forEach(event=>event.event==='modifyRecord'?event.callback():'');
    if(afterRecord.error){
      return afterRecord.error;
    }else {
      return '';
    }
  }
  private async updateRecord(id: string,concept: string, value: number, date: Date, notes?: string, category?: string): Promise<string>{
    const afterRecord = await this.db.query().data.updateData(
      'record',
      {concept, value,  date: date.getTime(), notes, category}, new Function('return ' + `function(...args){
        let {${Object.keys({ id })}} = JSON.parse('${JSON.stringify({ id })}');
        return ((value,tempId)=>tempId === id)(...args);
      }`)()
    );
    if(afterRecord.error){
      return afterRecord.error;
    }else {
      return '';
    }
  };

  private async addRecord(concept: string, value: number, date: Date, notes?: string, category?: string): Promise<string>{
    const afterRecord = await this.db.query().data.createData('record', {concept, value, date: date.getTime(), notes, category});
    if(afterRecord.error){
      return afterRecord.error;
    }else {
      return '';
    }
  }

  private async getRecordsFilter(
    page: number = 0,
    category?: string[],
    month?: number,
    year?: number,
    numberOfMonths?: number,
    gains?: boolean
  ): Promise<Array<Record>>{
    const operationList = [];
    if (typeof category !== 'undefined') {
      operationList.push({
        type:'filter',
        executable:new Function('return ' + `function(...args){
          let {${Object.keys({category})}} = JSON.parse('${JSON.stringify({category})}');
          return ((record) => typeof record.category === 'string' ? category.includes(record.category):false)(...args);
        }`)()
      });
    }
    if (typeof gains !== 'undefined') {
      operationList.push({
        type:'filter',
        executable:new Function('return ' + `function(...args){
          let {${Object.keys({gains})}} = JSON.parse('${JSON.stringify({gains})}');
          return ((record) => record.value>0&&gains || record.value<0&&!gains)(...args);
        }`)()
      });
    }
    if (typeof month !== 'undefined' && typeof year !== 'undefined' && typeof numberOfMonths !== 'undefined') {
      operationList.push({
        type:'filter',
        executable:new Function('return ' + `function(...args){
          let {${Object.keys({month,year,numberOfMonths})}} = JSON.parse('${JSON.stringify({month,year,numberOfMonths})}');
          return ((record) => {
            const recordDate = new Date(record.date);
            const startMonth = new Date(year, month - numberOfMonths + 1, 1);
            const endMonth = new Date(year, month + 1, 1);
            return (recordDate < endMonth && recordDate > startMonth);
          })(...args);
        }`)()
      });
    }
    operationList.push({
      type:'sort',
      executable:(a: {date: number}, b: {date: number})=>b.date - a.date
    });
    if (page !== -1) {
      operationList.push({
        type:'filter',
        executable:new Function('return ' + `function(...args){
          let {${Object.keys({page})}} = JSON.parse('${JSON.stringify({page})}');
          return ((record, id, allRecords, index) =>  Math.floor(index / 15) === page)(...args);
        }`)()
      });
    }
    const queryResult = await this.db.query().data.getData( 'record',undefined,undefined, operationList);
    const records = Object.keys(queryResult.result).map((recordID)=>{
      const record = queryResult.result[recordID];
      record.date = new Date(record.date);
      return {id:recordID, ...record};
    });
    return records.sort((a,b)=>b.date-a.date);
  }
}
