import { ViewChild } from '@angular/core';
import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import { CategoryService } from 'src/app/services/category.service';
import { Balance } from 'src/app/services/db.service';
import { RecordService } from 'src/app/services/record.service';
import { UtilsService } from 'src/app/services/utils.service';

@Component({
  selector: 'app-pie',
  templateUrl: './pie.component.html',
  styleUrls: ['./pie.component.css']
})
export class PieComponent implements OnInit, AfterViewInit {
  @ViewChild('canvas') canvas: any;
  data: any = {
    type: 'pie',
    data: {},
    options: {
      plugins: {
        tooltip: {
          callbacks: {
            label: (context: any) => {
              let label = context.label || '';
              if (label) {
                label += ': ';
              }
              if (context.parsed !== null) {
                label += this.utils.displayCurrency(context.parsed);
                label += ' (' + (Math.floor(context.parsed * 10000 / this.total) / 100) + '%)';
              }
              return label;
            }
          }
        }
      },
      onClick: (evt: any, item: any) => {
        const index = item?.[0]?.index;
        if (typeof index === 'number') {
          this.changeChart(index);
        }
      }
    }
  };
  chart: any;
  public total = 0;
  public breadcrumps: { name: string; selectedGains: undefined | boolean; selectedCategory: undefined | string }[] = [];
  private selectedGains: undefined | boolean = undefined;
  private selectedCategory: undefined | string = undefined;
  private triggers: { selectedGains?: undefined | boolean; selectedCategory?: undefined | string }[] = [];
  constructor(public utils: UtilsService, public categoryService: CategoryService, public recordService: RecordService) { }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    this.chart = new Chart(this.canvas.nativeElement.getContext('2d'), this.data);
    this.updateChart();
    this.recordService.addEventListener('changeDate', () => {
      this.selectedCategory = undefined;
      this.selectedGains = undefined;
      this.updateChart();
    });
    this.recordService.addEventListener('modifyRecord', () => {
      this.selectedCategory = undefined;
      this.selectedGains = undefined;
      this.updateChart();
    });
  }
  async updateChart(): Promise<void> {
    if (typeof this.selectedGains === 'undefined') {
      await this.updateGainLossChart();
    } else {
      if (typeof this.selectedCategory === 'undefined') {
        this.updateCategoriesChart();
      } else {
        this.updateSubCategoriesChart();
      }
    }
    this.chart.update();
  }

  async changeChart(index: number) {
    if (this.triggers[index]) {
      this.selectedGains = this.triggers[index].selectedGains;
      this.selectedCategory = this.triggers[index].selectedCategory;
    }
    await this.updateChart();
  }
  async goToChart(selectedGains: undefined | boolean, selectedCategory: undefined | string) {
    this.selectedGains = selectedGains;
    this.selectedCategory = selectedCategory;
    await this.updateChart();
  }

  private async updateGainLossChart(): Promise<void> {
    const monthBalance = await this.recordService.monthBalance(
      this.recordService.filters.month || new Date().getMonth(),
      this.recordService.filters.year || new Date().getFullYear()
    );
    // Update filters
    this.recordService.updateFilter.category();
    this.recordService.updateFilter.gains();
    // Change total
    this.total = monthBalance.gains - monthBalance.losses;
    // Change Labels
    this.chart.data.labels = ['Gains', 'Losses'];
    // Change triggers
    this.triggers = [{ selectedGains: true, selectedCategory: undefined }, { selectedGains: false, selectedCategory: undefined }];
    // Change breadcrumps
    this.updateBreadCrumbs();
    // Change data
    this.chart.data.datasets = [
      {
        label: '',
        data: [monthBalance.gains, -monthBalance.losses],
        backgroundColor: ['#2EC4B6', '#E33742']
      }
    ];
    this.chart.update();
  }
  private updateCategoriesChart() {
    // Set filters
    this.recordService.updateFilter.gains(this.selectedGains);
    this.recordService.updateFilter.category();

    // Calculate ourBalance and needed categories
    const ourBalance = JSON.parse(JSON.stringify(this.categoryService.balances));
    let neededCategories = Object.keys(ourBalance).filter(
      categoryId =>
        this.selectedGains && ourBalance[categoryId].gains > 0 ||
        !this.selectedGains && ourBalance[categoryId].losses < 0
    ).reduce((prev: string[], id) => {
      const parentCatId = this.categoryService.categories.find(category => category.id === id)?.category;
      if (
        typeof parentCatId !== 'undefined' &&
        parentCatId !== '' &&
        this.categoryService.categories.find(category => category.id === parentCatId)
      ) {
        if(!ourBalance[parentCatId]){
          ourBalance[parentCatId]={
            total:0,
            gains:0,
            losses:0
          };
        }
        ourBalance[parentCatId].total += ourBalance[id].total;
        ourBalance[parentCatId].gains += ourBalance[id].gains;
        ourBalance[parentCatId].losses += ourBalance[id].losses;
        prev.push(parentCatId);
      } else {
        prev.push(id);
      }
      return prev;
    }, []);
    neededCategories = [...new Set(neededCategories)];

    // Update total
    this.updateTotal(neededCategories, ourBalance);
    // Update labels
    this.updateLabels(neededCategories);
    // Update triggers
    this.triggers = neededCategories.map(id => {
      const name = id === '' ?
        'Unasigned category' :
        this.categoryService.categories.find(category => category.id === id)?.name;
      return { name, selectedGains: this.selectedGains, selectedCategory: id === '' ? undefined : id };
    });
    // Update breadcrumps
    this.updateBreadCrumbs();
    // Update data
    this.updateData(neededCategories, ourBalance);
  }
  private updateSubCategoriesChart() {
    if (typeof this.selectedCategory === 'undefined') {
      return;
    }
    // Calculate our balance and needed categories
    const ourBalance = JSON.parse(JSON.stringify(this.categoryService.balances));
    const neededCategories = Object.keys(ourBalance).filter(
      categoryId => {
        const checksGains = this.selectedGains && ourBalance[categoryId].gains > 0 ||
          !this.selectedGains && ourBalance[categoryId].losses < 0;
        const checksCat = this.categoryService.categories.find(category =>
          category.id === categoryId && category.category === this.selectedCategory
        );
        return checksGains && checksCat;
      }
    );
    neededCategories.unshift(this.selectedCategory);
    if(!ourBalance[this.selectedCategory]){
      ourBalance[this.selectedCategory]={
        total: 0,
        gains: 0,
        losses: 0
      };
    }
    // Update filter
    this.recordService.updateFilter.gains(this.selectedGains);
    this.recordService.updateFilter.category(neededCategories);

    // Add labels
    this.updateLabels(neededCategories);
    // Calculate total
    this.updateTotal(neededCategories, ourBalance);
    // Update triggers
    this.triggers = [];
    // Update Breadcrumps
    this.updateBreadCrumbs();
    // Update data
    this.updateData(neededCategories, ourBalance);
  }
  private updateTotal(neededCategories: string[], ourBalance: { [id: string]: Balance }) {
    this.total = neededCategories.reduce(
      (prev, id) =>
        prev + (this.selectedGains ? ourBalance[id].gains : -ourBalance[id].losses),
      0
    );
  }
  private updateLabels(neededCategories: string[]) {
    this.chart.data.labels = neededCategories.map(id =>
      id === '' ?
        'Unasigned category' :
        this.categoryService.categories.find(category => category.id === id)?.name
    );
  }
  private updateBreadCrumbs() {
    this.breadcrumps = [
      { name: 'Gains/Losses', selectedGains: undefined, selectedCategory: undefined },
    ];
    if (typeof this.selectedGains !== 'undefined') {
      this.breadcrumps.push({
        name: this.selectedGains ? 'Gains' : 'Losses',
        selectedGains: this.selectedGains,
        selectedCategory: undefined
      });
      if (typeof this.selectedCategory !== 'undefined') {
        this.breadcrumps.push({
          name: this.categoryService.categories.find( category => category.id === this.selectedCategory )?.name||'',
          selectedGains: this.selectedGains,
          selectedCategory: this.selectedCategory
        });
      }
    }
  }
  private updateData(neededCategories: string[], ourBalance: { [id: string]: Balance }) {
    this.chart.data.datasets = [
      {
        label: '',
        data: neededCategories.map(id =>
          this.selectedGains ? ourBalance[id].gains : -ourBalance[id].losses
        ),
        backgroundColor: neededCategories.map(id => {
          const color = id === '' ? '#FAFAFA' : this.categoryService.categories.find(category => category.id === id)?.color;
          return color || '#FAFAFA';
        })
      }
    ];
  }
}
