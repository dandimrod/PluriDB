import { Injectable } from '@angular/core';
import { Balance, Category, DbService, Record } from './db.service';
import { RecordService } from './record.service';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  public categories: Array<Category> = [];
  public balances: { [id: string]: Balance } = {};
  constructor(private db: DbService, private recordService: RecordService) {
    this.getCategories();
    recordService.addEventListener('modifyRecord',()=>{this.getCategories();});
    recordService.addEventListener('changeDate',()=>{this.getCategories();});
  }

  public async getCategories(){
    const categories = await this.db.query().data.getData('category');
    this.categories = Object.keys(categories.result).map((categoryID)=>{
      const category = categories.result[categoryID];
      return {id:categoryID, ...category};
    });
    const operationList = [];
    const { month, year, numberOfMonths } = this.recordService.filters;
    if (typeof month !== 'undefined' && typeof year !== 'undefined' && typeof numberOfMonths !== 'undefined') {
      operationList.push({
        type:'filter',
        executable:new Function('return ' + `function(...args){
          let {${Object.keys( {month,year,numberOfMonths} )}} = JSON.parse('${JSON.stringify( {month,year,numberOfMonths} )}');
          return ( (record) => {
            const recordDate = new Date(record.date);
            const startMonth = new Date(year, month - numberOfMonths + 1, 1);
            const endMonth = new Date(year, month + 1, 1);
            return (recordDate < endMonth && recordDate > startMonth);
          } )(...args);
        }`)()
      });
    }
    operationList.push({
      type:'reduce',
      initialValue: {},
      executable:(currentBalance: any, record: Record) => {
        let id = '';
        if (record.category && record.category!=='') {
          id = record.category;
        }
        if(!currentBalance[id]){
          currentBalance[id]={ total: 0, gains: 0, losses: 0 };
        }
        if(record.value>0){
          currentBalance[id].gains+=record.value;
        }else{
          currentBalance[id].losses+=record.value;
        }
        currentBalance[id].total+=record.value;
        return currentBalance;
      }
    });
    const balances = await this.db.query().data.getData('record', undefined, undefined, operationList);
    this.balances = balances.result;
  }

  public async saveCategory(category: Category): Promise<string>{
    let afterOp;
    if(category.id!==''){
      const { id } = category;
      afterOp = await this.db.query().data.updateData('category', {
        name:category.name,
        color:category.color,
        periodic:category.periodic,
        category:category.category
      }, new Function('return ' + `function(...args){
        let {${Object.keys({ id })}} = JSON.parse('${JSON.stringify({ id })}');
        return ((value,tempId)=>tempId === id)(...args);
      }`)());
    }else{
      afterOp = await this.db.query().data.createData('category', {
        name:category.name,
        color:category.color,
        periodic:category.periodic,
        category:category.category
      });
    }
    await this.getCategories();
    if(afterOp.error){
      return afterOp.error;
    }else {
      return '';
    }
  }
  public async deleteCategory(id: string){
    const afterOp = await this.db.query().data.deleteData(
      'category', new Function('return ' + `function(...args){
        let {${Object.keys({ id })}} = JSON.parse('${JSON.stringify({ id })}');
        return ((value,tempId)=>tempId === id)(...args);
      }`)()
    );
    await this.getCategories();
    if(afterOp.error){
      return afterOp.error;
    }else {
      return '';
    }
  }
}
