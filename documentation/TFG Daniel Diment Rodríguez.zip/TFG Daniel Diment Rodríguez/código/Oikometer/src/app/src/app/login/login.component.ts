import { Component, OnInit } from '@angular/core';
import { DbService } from '../services/db.service';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public db: DbService, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
    iconRegistry.addSvgIcon('oikometer-logo', sanitizer.bypassSecurityTrustResourceUrl('./assets/icons/oikometer.svg'));
  }

  ngOnInit(): void {
  }
  public submit(user: string, pass: string){
    this.db.login(user, pass);
  }
}
