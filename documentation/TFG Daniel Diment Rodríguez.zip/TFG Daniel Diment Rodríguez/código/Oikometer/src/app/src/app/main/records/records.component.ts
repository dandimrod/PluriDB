import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from 'src/app/services/category.service';
import { RecordService } from 'src/app/services/record.service';
import { UtilsService } from 'src/app/services/utils.service';
import { DbService, Record } from '../../services/db.service';
@Component({
  selector: 'app-records',
  templateUrl: './records.component.html',
  styleUrls: ['./records.component.css']
})
export class RecordsComponent implements OnInit {
  public id: string|null = null;
  public bulk = false;
  public record: Record = {
    concept:'',
    id:'',
    value: 0,
    date: new Date(),
    notes: '',
    category: ''
  };
  public records: Record[] = [];
  public displayedColumns: string[] = ['concept','value','date'];
  constructor(
    private activatedRoute: ActivatedRoute,
    public recordService: RecordService,
    public categoryService: CategoryService,
    private snackBar: MatSnackBar,
    public utils: UtilsService
  ) {
  }

  async ngOnInit(): Promise<void> {
    this.id = this.activatedRoute.snapshot.fragment;
    if(this.id){
      const tempRecord = await this.recordService.getRecord(this.id);
      if(!tempRecord){
        this.id = null;
        this.record = {
          concept:'',
          id:'',
          value: 0,
          date: new Date(),
          notes: '',
          category: ''
        };
      }else{
        this.record = tempRecord;
      }
    }
  }

  public async saveOne(): Promise<void>{
    const error = await this.recordService.modifyRecord(this.record);
    if(error){
      this.snackBar.open(error,undefined,{
        duration: 5000,
      });
    }else{
      this.snackBar.open('Done', undefined, {
        duration: 5000,
      });
    }
  }

  public async saveMany(): Promise<void>{
    const error = await this.recordService.addRecords(this.records);
    if(error){
      this.snackBar.open(error,undefined,{
        duration: 5000,
      });
    }else{
      this.snackBar.open('Done', undefined, {
        duration: 5000,
      });
    }
    this.records = [];
  }
  public async uploadFile(): Promise<void>{
    const fileElement = document.createElement('input');
    fileElement.type = 'file';
    fileElement.click();
    fileElement.onchange = (event: any)=>{
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        const text = reader.result;
        if(text && typeof text === 'string'){
          const tempRecordList = [];
          const textRecords = text.split('\n');
          let endOnError = false;
          for (const textRecord of textRecords) {
            const splittedRecord = textRecord.split(',');
            const record: Record =  {
              id:'',
              concept:'',
              value:0,
              date:new Date(),
              notes:'',
              category:''
            };
            record.concept = splittedRecord[0];
            try {
              record.value = Number(splittedRecord[1]);
              record.date = new Date(splittedRecord[2]);
            } catch (error) {
              endOnError = true;
              break;
            }
            if(endOnError){
              this.snackBar.open('Error reading the file',undefined,{
                duration: 5000,
              });
            }else{
              tempRecordList.push(record);
            }
          }
          this.records=tempRecordList;
        }
      };
      reader.readAsText(file);
    };
  }

  public updateDate(value: any): void{
    const date = value?.target?.value;
    if(date){
      this.record.date = new Date(date);
    }
  }
  public getDate(): string{
    return this.record.date.toISOString().slice(0,-1);
  }
}
