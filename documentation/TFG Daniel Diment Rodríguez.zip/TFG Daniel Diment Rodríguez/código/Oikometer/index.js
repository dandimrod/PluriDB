const { exec } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
function serve() {

}

async function build() {
    async function copy404() {
        let file = await fs.readFile('./docs/app/index.html','utf-8');
        file = file.replace('<base href="./">', '<base href="./app/">');
        await fs.writeFile('./docs/404.html', file, 'utf-8');
    }
    async function copyBuild() {
        await fs.copy('./src/app/dist/oikometer','./docs/app');
    }
    async function copyStatic() {
        if(fs.existsSync('./docs/')){
            await fs.unlink('./docs/');
        }
        await fs.mkdir('./docs/');
        const files = await fs.readdir('./src/');
        for (let index = 0; index < files.length; index++) {
            const file = files[index];
            if (file !== 'app') {
                await fs.copy(path.join('./src', file), path.join('./docs', file));
            }
        }
    }
    function ngBuild() {
        return new Promise((resolve, reject) => {
            exec('npm run build', { cwd: './src/app' }, (error, stdout, stderr) => {
                if (error) {
                    console.error(`exec error: ${error}`);
                    reject();
                }
                console.log(`stdout: ${stdout}`);
                console.error(`stderr: ${stderr}`);
                resolve();
            })
        })
    }
    async function main() {
        console.log('Starting build process...');
        console.log('Building app');
        await ngBuild();
        console.log('Copying static files');
        await copyStatic();
        console.log('Copying build files');
        await copyBuild();
        console.log('Adding 404 routing');
        await copy404();
        console.log('Build end');
    }
    return await main();
}


function main() {
    build()
}

main();